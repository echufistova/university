//
// Created by echufy on 22.09.18.
//

#ifndef SPL1_SPL1_H
#define SPL1_SPL1_H

# include <unistd.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <ctype.h>

typedef struct		s_dictionary
{
    char			*content;
    int             times;
//    struct s_dictionaty *next;
}					t_dictionary;
#endif //SPL1_SPL1_H
