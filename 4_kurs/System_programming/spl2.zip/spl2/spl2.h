//
// Created by echufy on 10.10.18.
//

#ifndef SPL2_SPL2_H
#define SPL2_SPL2_H

# include <unistd.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <ctype.h>
#include <stdio.h>
#include "libft/libft.h"
#include "get_next_line.h"

typedef struct  s_link
{
    int     poch;
    char    stan;
    int     kinc;
}                t_link;

#endif //SPL2_SPL2_H
